package com.example.municipali3;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import android.annotation.SuppressLint;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;


public class SQLhelper extends SQLiteOpenHelper {

	  public static final String TABLE_COMMENTS = "my_complaints";
	  public static final String COLUMN_ID = "_id";
	  public static final String COLUMN_COMMENT = "complaint";
	  public static final String COLUMN_LATITUDE = "lat";
	  public static final String COLUMN_LONG = "lng";
	  public static final String COLUMN_DESC = "description";
	  public static final String COLUMN_LANDMARK = "landmark"; 

	  private static final String DATABASE_NAME = "complaints.db";
	  private static final int DATABASE_VERSION = 15;

	  private static final String DATABASE_PHONE = "AUTH";
	  private static final String PHONE = "PHONE";
	  private static final String IMEI = "IMEI";
	  private static final String DATABASE_CREATE = "create table "
	      + TABLE_COMMENTS + "(" + COLUMN_ID
	      + " integer primary key autoincrement, " + COLUMN_COMMENT + " text not null, " + COLUMN_DESC +" text not null, " 
	       + COLUMN_LATITUDE + " real not null, " +   COLUMN_LONG +  " real, " + COLUMN_LANDMARK  +" text not null);";
	  
	  private static final String DATABASE_CREATE_PHONE = "create table "
		      + DATABASE_PHONE + "(" + IMEI
		      + " text primary key , " + "NAME text, " + PHONE + " text);";

	  @Override
	  public void onCreate(SQLiteDatabase database) {
		database.execSQL(DATABASE_CREATE_PHONE);
	    database.execSQL(DATABASE_CREATE);
	
	  }

	  @Override
	  public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
	    Log.w(SQLhelper.class.getName(),
	        "Upgrading database from version " + oldVersion + " to "
	            + newVersion + ", which will destroy all old data");
	    db.execSQL("DROP TABLE IF EXISTS " + TABLE_COMMENTS);
	    db.execSQL("DROP TABLE IF EXISTS " + DATABASE_PHONE);
	    onCreate(db);
	  }

	

	public SQLhelper(Context context) {
		// TODO Auto-generated constructor stub
		super(context, DATABASE_NAME, null, DATABASE_VERSION);
	}

    public void insertComplaints(HashMap<String, String> queryValues) {
        SQLiteDatabase database = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_COMMENT, queryValues.get(COLUMN_COMMENT));
        values.put(COLUMN_LATITUDE, queryValues.get(COLUMN_LATITUDE));
        values.put(COLUMN_LONG, queryValues.get(COLUMN_LONG));
        values.put(COLUMN_DESC, queryValues.get(COLUMN_DESC));
        values.put(COLUMN_LANDMARK, queryValues.get(COLUMN_LANDMARK));
        database.insert(TABLE_COMMENTS, null, values);
        database.close();
    }
    
    public void insertPhone(String ph, String name, String IME) {
        SQLiteDatabase database = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("PHONE", ph);
        values.put("NAME", name);
        String fil = IMEI + " = " + IME;
        database.update(DATABASE_PHONE,values, fil, null);
        database.close();
    }
    
    public void insertIMEI(String IME) {
        SQLiteDatabase database = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        
        values.put("IMEI", IME);
        database.insert(DATABASE_PHONE, null, values);
        database.close();
    }
    
    public ArrayList<String> getAllComplaintsText()
    {
    	ArrayList<String> comps = new ArrayList<String>();
    	String selectQuery = "SELECT  complaint FROM " + TABLE_COMMENTS;
        SQLiteDatabase database = this.getWritableDatabase();
        Cursor cursor = database.rawQuery(selectQuery, null);
        if (cursor.moveToFirst()) {
            do {
                
                comps.add(cursor.getString(0));
                
            } while (cursor.moveToNext());
        }
    	return comps;
    }
    
    public String getName()
    {
    	String nam = "";
    	String selectQuery = "SELECT  name FROM " + DATABASE_PHONE;
        SQLiteDatabase database = this.getWritableDatabase();
        Cursor cursor = database.rawQuery(selectQuery, null);
        if (cursor.moveToFirst()) {
                            
                nam = cursor.getString(0);
                
        		}
        return nam;
    }
    public List<Complaint> getAllComplaints() {
        List<Complaint> wordList;
        wordList = new ArrayList<Complaint>();
        String selectQuery = "SELECT  * FROM " + TABLE_COMMENTS;
        SQLiteDatabase database = this.getWritableDatabase();
        Cursor cursor = database.rawQuery(selectQuery, null);
        if (cursor.moveToFirst()) {
            do {
                Complaint complaint = new Complaint();
                complaint.setComplaint(cursor.getString(0));
                complaint.setDescription(cursor.getString(1));
                complaint.setLocation(Double.parseDouble(cursor.getString(2)),Double.parseDouble(cursor.getString(3)));
                wordList.add(complaint);
            } while (cursor.moveToNext());
        }
        return wordList;
    }
    @SuppressLint("NewApi")
	public long getIMEI()
    {
    	String selectQuery = "SELECT  IMEI FROM AUTH";
        SQLiteDatabase database = this.getWritableDatabase();
        Cursor cursor = database.rawQuery(selectQuery, null);
        if(cursor.moveToFirst())
        {
        	if((cursor.getString(0) == null))
        	{
        	return 0;
        	}
        	
        	if((cursor.getString(0).isEmpty()))
        	{
        		return 0;
        	}
        	else
        	{
        		return Long.parseLong(cursor.getString(0));
        	}
        }
        else
        {
    	return 0;
        }
    }
    @SuppressLint("NewApi")
	public long getPHONE()
    {
    	String selectQuery = "SELECT  PHONE FROM AUTH";
        SQLiteDatabase database = this.getWritableDatabase();
        Cursor cursor = database.rawQuery(selectQuery, null);
        if(cursor.moveToFirst())
        {
        	if((cursor.getString(0) == null))
        	{
        	return 0;
        	}
        	if((cursor.getString(0).isEmpty()))
        	{
        		return 0;
        	}
        	else
        	{
        		return Long.parseLong(cursor.getString(0));
        	}
        }
        else
        {
    	return 0;
        }
    }
    @SuppressLint("NewApi")
	public String getPHONES()
    {
    	String selectQuery = "SELECT  PHONE FROM AUTH";
        SQLiteDatabase database = this.getWritableDatabase();
        Cursor cursor = database.rawQuery(selectQuery, null);
        if(cursor.moveToFirst())
        {
        	if((cursor.getString(0) == null))
        	{
        	return null;
        	}
        	if((cursor.getString(0).isEmpty()))
        	{
        		return null;
        	}
        	else
        	{
        		return cursor.getString(0);
        	}
        }
        else
        {
    	return null;
        }
    }
}