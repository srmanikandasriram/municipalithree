package com.example.municipali3;

import java.util.ArrayList;
import java.util.List;

import android.net.Uri;
import android.os.Bundle;
import android.telephony.TelephonyManager;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Context;
import android.view.Menu;
import android.content.Intent;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;
import android.content.SharedPreferences;
import android.app.ListActivity;
import android.widget.ArrayAdapter;
import android.view.View;
public class MainActivity extends Activity{

	private EditText Complaint;
	private EditText Description;
	private EditText Phone;
	private Uri todoUri;
	private ListView lview;
	
	private CommentsDataSource datasource;
	
	@SuppressLint("NewApi")
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		SQLhelper sql = new SQLhelper(this);
		TelephonyManager device = (TelephonyManager)getSystemService(Context.TELEPHONY_SERVICE);
		Button enterphone = (Button)findViewById(R.id.accept_phone);
		String IME = device.getDeviceId();
		if(sql.getIMEI() == 0)
		{
	
		
		Toast.makeText(getApplicationContext(), IME, Toast.LENGTH_SHORT).show();
		sql.insertIMEI(IME);
		
		}
		if(sql.getPHONE() == 0)
		{
			setContentView(R.layout.activity_loggedout);	
		}
		else
		{
			setContentView(R.layout.activity_main);
			//lview = (ListView)findViewById(R.id.list);
			
			
		}
		
		refreshView();
		
	}

	/*public void listClick(ArrayAdapter<?> A, View v, int position, long id)
	{
		Toast.makeText(getApplicationContext(),
			      "Click ListItem Number " + position, Toast.LENGTH_LONG)
			      .show();
	}*/
	public void launchComplaint(View v)
	{
		Intent c_screen = new Intent(this, LodgeComplaint.class);
		startActivityForResult(c_screen, 1);
		
	}
	public void onActivityResult(int reqcode, int rescode, Intent data)
	{
		SQLhelper sql = new SQLhelper(this);
		lview = (ListView)findViewById(R.id.list);
		if(lview != null)
		{
		ArrayList<String> items = sql.getAllComplaintsText();
		if(items.isEmpty())
		{
			String[] ites = new String[] {"You haven't lodged any complaints yet"};
		    ArrayAdapter<String> adapter = new ArrayAdapter<String>(this, R.layout.list_content, ites);
		    lview.setAdapter(adapter);
		}
		else
		{
		ArrayAdapter<String> adapter = new ArrayAdapter<String>(this, R.layout.list_content,items);
		lview.setAdapter(adapter);
		}
		
		}
	}
	public void refreshView()
	{
		SQLhelper sql = new SQLhelper(this);
		lview = (ListView)findViewById(R.id.list);
		
		if(lview != null)
		{
		ArrayList<String> items = sql.getAllComplaintsText();
		if(items.isEmpty())
		{
			String[] ites = new String[] {"You haven't lodged any complaints yet"};
		    ArrayAdapter<String> adapter = new ArrayAdapter<String>(this, R.layout.list_content, ites);
		    lview.setAdapter(adapter);
		}
		else
		{
		ArrayAdapter<String> adapter = new ArrayAdapter<String>(this, R.layout.list_content,items);
		lview.setAdapter(adapter);
		}
		
		}
	}
	public void savePhone(View v)
	{
		Phone = (EditText)findViewById(R.id.editText1);
		EditText nam = (EditText)findViewById(R.id.editname);
		String ph = Phone.getText().toString();
		String name = nam.getText().toString();
		if(ph.length() != 10)
		{
			Toast.makeText(getApplicationContext(),"Please Enter Proper Phone number", Toast.LENGTH_LONG).show();
		}
		else
		{
		TelephonyManager deve = (TelephonyManager)getSystemService(Context.TELEPHONY_SERVICE);
		String IM = deve.getDeviceId();
		SQLhelper sq = new SQLhelper(this);
		sq.insertPhone(ph, name, IM);
		setContentView(R.layout.activity_main);
		}
	}
	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.main, menu);
		return true;
	}
	
	 public void onClick(View view) {
	
		  }


		 		 
}