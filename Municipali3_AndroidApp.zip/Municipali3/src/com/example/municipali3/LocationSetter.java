package com.example.municipali3;

import android.os.Bundle;

import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.MapFragment;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.StatusLine;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.DefaultHttpClient;

import android.os.AsyncTask;
import android.location.Location;
import android.location.LocationManager;
import android.content.Context;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.support.v4.app.FragmentActivity;
import android.view.Menu;
import android.widget.Toast;

public class LocationSetter extends FragmentActivity {
	
	private GoogleMap theMap;
	private boolean map_flag = true;
	private LocationManager LocMan;
	private double search_radius = 200;
	
	

	@SuppressLint("NewApi")
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_location_setter);
		if(theMap == null)
		{
			theMap = ((MapFragment)getFragmentManager().findFragmentById(R.id.the_map)).getMap();
			
			if(theMap != null)
			{
				map_flag = true;
			}
	
		}
		
	
		
		if(map_flag)
		{
		theMap.setMapType(GoogleMap.MAP_TYPE_HYBRID);
		
		LocMan = (LocationManager)getSystemService(Context.LOCATION_SERVICE);
		if(LocMan == null)
		{
			Toast.makeText(getApplicationContext(), "LocMan Cups :(", Toast.LENGTH_SHORT).show();
		}
		else
		{
		LatLng locs = getLocation();
		theMap.animateCamera(CameraUpdateFactory.newLatLngZoom(locs, 19), 3000, null);
		MarkerOptions marker = new MarkerOptions().position(locs).title("Current Location");
		theMap.addMarker(marker);
		locationFixer(locs);
		//theMap.
		//Toast.makeText(getApplicationContext(), String.valueOf(locs.latitude), Toast.LENGTH_SHORT).show();
		}
		}
	
	}

	protected void locationFixer(LatLng locs)
	{
		
		String searchStr = "https://maps.googleapis.com/maps/api/place/nearbysearch/" +
			    "json?location="+locs.latitude+","+locs.longitude+
			    "&radius="+search_radius+"&sensor=true" +
			    "&key=your_key_here";
	}
	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.location_setter, menu);
		return true;
	}
	
	private LatLng getLocation()
	{
		if(!LocMan.isProviderEnabled(LocationManager.GPS_PROVIDER))
		{
			Toast.makeText(getApplicationContext(), "Oops! GPS Target is Not Enabled.We'll try to get an inaccurate location", Toast.LENGTH_SHORT).show();
			Location lastLoc = LocMan.getLastKnownLocation(LocationManager.NETWORK_PROVIDER);
			double lat= lastLoc.getLatitude();
			double lng = lastLoc.getLongitude();
			LatLng coords = new LatLng(lat,lng);
			return coords;
		}
		else
		{
		Location lastLoc = LocMan.getLastKnownLocation(LocationManager.GPS_PROVIDER);
		double lat= lastLoc.getLatitude();
		double lng = lastLoc.getLongitude();
		LatLng coords = new LatLng(lat,lng);
		return coords;
	}
	}

}
