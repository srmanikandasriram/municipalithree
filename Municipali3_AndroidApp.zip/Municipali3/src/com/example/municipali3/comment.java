package com.example.municipali3;

public class comment {
	  private long id;
	  private String Comment;

	  public long getId() {
	    return id;
	  }

	  public void setId(long id) {
	    this.id = id;
	  }

	  public String getComment() {
	    return Comment;
	  }

	  public void setComment(String Comment) {
	    this.Comment = Comment;
	  }

	  // Will be used by the ArrayAdapter in the ListView
	  @Override
	  public String toString() {
	    return Comment;
	  }
}
