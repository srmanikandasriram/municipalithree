package com.example.municipali3;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.apache.http.HttpResponse;
import org.apache.http.HttpStatus;
import org.apache.http.NameValuePair;
import org.apache.http.StatusLine;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;

import android.os.AsyncTask;

class RequestTask extends AsyncTask<String, String, String>{

	/*private String brief;
	private String desc;
	private double lat;
	private double lng;
	private String landmark;
	private String latlon;
	private String Name;
	private long Phone;
	public RequestTask(String b, String d, double l, double ln, String n, long ph)
	{
		brief = b;
		desc = d;
		lat = l;
		lng = ln;
		//l_n = landmark;
		latlon = Double.toString(l) + "," + Double.toString(ln);
		Name = n;
		Phone = ph;
	}*/
	//public static String URL = "http://municipalithree.appspot.com/api";
    protected String doInBackground(String... uri) {
        HttpClient httpclient = new DefaultHttpClient();
        //HttpPost httppost = new HttpPost();
        HttpResponse response;
        String responseString = null;
        try {
       /* 	List<NameValuePair> nameValuePairs = new ArrayList<NameValuePair>(4);
	        nameValuePairs.add(new BasicNameValuePair("title", brief));
	        nameValuePairs.add(new BasicNameValuePair("desc", desc));
	        nameValuePairs.add(new BasicNameValuePair("loc", latlon));
	        nameValuePairs.add(new BasicNameValuePair("name", Name));
	        
	        nameValuePairs.add(new BasicNameValuePair("phno", Double.toString(Phone)));
	        httppost.setEntity(new UrlEncodedFormEntity(nameValuePairs));*/
            response = httpclient.execute(new HttpGet(uri[0]));
            StatusLine statusLine = response.getStatusLine();
            if(statusLine.getStatusCode() == HttpStatus.SC_OK){
                ByteArrayOutputStream out = new ByteArrayOutputStream();
                response.getEntity().writeTo(out);
                out.close();
                responseString = out.toString();
            } else{
                //Closes the connection.
                response.getEntity().getContent().close();
                throw new IOException(statusLine.getReasonPhrase());
            }
        } catch (ClientProtocolException e) {
            //TODO Handle problems..
        } catch (IOException e) {
            //TODO Handle problems..
        }
        return responseString;
    }

    protected void onPostExecute(String result) {
        super.onPostExecute(result);
        //Do anything with response..
    }
}