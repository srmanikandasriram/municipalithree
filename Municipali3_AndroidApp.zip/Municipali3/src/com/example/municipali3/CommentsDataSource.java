package com.example.municipali3;

import java.util.ArrayList;
import java.util.List;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;

public class CommentsDataSource {

  // Database fields
  private SQLiteDatabase database;
  private SQLhelper dbHelper;
  private String[] allColumns = { SQLhelper.COLUMN_ID,
      SQLhelper.COLUMN_COMMENT };

  public CommentsDataSource(Context context) {
    dbHelper = new SQLhelper(context);
  }

  public void open() throws SQLException {
    database = dbHelper.getWritableDatabase();
  }

  public void close() {
    dbHelper.close();
  }

  public comment createcomment(String comment) {
    ContentValues values = new ContentValues();
    values.put(SQLhelper.COLUMN_COMMENT, comment);
    long insertId = database.insert(SQLhelper.TABLE_COMMENTS, null,
        values);
    Cursor cursor = database.query(SQLhelper.TABLE_COMMENTS,
        allColumns, SQLhelper.COLUMN_ID + " = " + insertId, null,
        null, null, null);
    cursor.moveToFirst();
    comment newcomment = cursorTocomment(cursor);
    cursor.close();
    return newcomment;
  }

  public void deletecomment(comment comment) {
    long id = comment.getId();
    System.out.println("comment deleted with id: " + id);
    database.delete(SQLhelper.TABLE_COMMENTS, SQLhelper.COLUMN_ID
        + " = " + id, null);
  }

  public List<comment> getAllcomments() {
    List<comment> comments = new ArrayList<comment>();

    Cursor cursor = database.query(SQLhelper.TABLE_COMMENTS,
        allColumns, null, null, null, null, null);

    cursor.moveToFirst();
    while (!cursor.isAfterLast()) {
      comment comment = cursorTocomment(cursor);
      comments.add(comment);
      cursor.moveToNext();
    }
    // make sure to close the cursor
    cursor.close();
    return comments;
  }

  private comment cursorTocomment(Cursor cursor) {
    comment comment = new comment();
    comment.setId(cursor.getLong(0));
    comment.setComment(cursor.getString(1));
    return comment;
  }
} 