package com.example.municipali3;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.concurrent.ExecutionException;

import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;

import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.MapFragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;

import android.location.Location;
import android.location.LocationManager;
import android.os.Bundle;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.support.v4.app.FragmentActivity;
import android.view.Menu;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class LodgeComplaint extends FragmentActivity {

	private GoogleMap theMap;
	private boolean map_flag = true;
	private LocationManager LocMan;
	private double search_radius = 200;
	private double lat,lng;
	public static final String COLUMN_COMMENT = "complaint";
	  public static final String COLUMN_LATITUDE = "lat";
	  public static final String COLUMN_LONG = "lng";
	  public static final String COLUMN_DESC = "description";
	  public static final String COLUMN_LANDMARK = "landmark"; 

	@SuppressLint("NewApi")
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_lodge_complaint);
		if(theMap == null)
		{
			theMap = ((MapFragment)getFragmentManager().findFragmentById(R.id.the_map)).getMap();
			
			if(theMap != null)
			{
				map_flag = true;
			}
	
		}
		
	
		
		if(map_flag)
		{
		theMap.setMapType(GoogleMap.MAP_TYPE_HYBRID);
		
		LocMan = (LocationManager)getSystemService(Context.LOCATION_SERVICE);
		if(LocMan == null)
		{
			Toast.makeText(getApplicationContext(), "LocMan Cups :(", Toast.LENGTH_SHORT).show();
		}
		else
		{
		LatLng locs = getLocation();
		theMap.animateCamera(CameraUpdateFactory.newLatLngZoom(locs, 17), 3000, null);
		MarkerOptions marker = new MarkerOptions().position(locs).title("Current Location");
		theMap.addMarker(marker);
		locationFixer(locs);
		//theMap.
		//Toast.makeText(getApplicationContext(), String.valueOf(locs.latitude), Toast.LENGTH_SHORT).show();
		}
		}
	
	}
	public void setLocation(View v)
	{
		LatLng locs = getLocation();
		theMap.animateCamera(CameraUpdateFactory.newLatLngZoom(locs, 17), 3000, null);
		MarkerOptions marker = new MarkerOptions().position(locs).title("Current Location");
		theMap.clear();
		theMap.addMarker(marker);
		locationFixer(locs);
	}
	protected void locationFixer(LatLng locs)
	{
		
		String searchStr = "https://maps.googleapis.com/maps/api/place/nearbysearch/" +
			    "json?location="+locs.latitude+","+locs.longitude+
			    "&radius="+search_radius+"&sensor=true" +
			    "&key=your_key_here";
	}
	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.location_setter, menu);
		return true;
	}
	
	private LatLng getLocation()
	{
		if(!LocMan.isProviderEnabled(LocationManager.GPS_PROVIDER))
		{
			Toast.makeText(getApplicationContext(), "Oops! GPS Target is Not Enabled.We'll try to get an inaccurate location", Toast.LENGTH_SHORT).show();
			Location lastLoc = LocMan.getLastKnownLocation(LocationManager.NETWORK_PROVIDER);
			lat= lastLoc.getLatitude();
			lng = lastLoc.getLongitude();
			LatLng coords = new LatLng(lat,lng);
			return coords;
		}
		else
		{
		Location lastLoc = LocMan.getLastKnownLocation(LocationManager.GPS_PROVIDER);
		lat= lastLoc.getLatitude();
		lng = lastLoc.getLongitude();
		LatLng coords = new LatLng(lat,lng);
		return coords;
		}
	}
	public void saveComplaint(View v) throws InterruptedException, ExecutionException
	{
		EditText brief = (EditText)findViewById(R.id.complaint);
		EditText desc  = (EditText)findViewById(R.id.editText1);
		EditText landmark = (EditText)findViewById(R.id.AC_view);
		SQLhelper sql = new SQLhelper(this);
		HashMap<String, String> data = new HashMap<String, String>();
		data.put(COLUMN_COMMENT, brief.getText().toString());
		data.put(COLUMN_DESC, desc.getText().toString());
		data.put(COLUMN_LATITUDE, Double.toString(lat));
		data.put(COLUMN_LONG, Double.toString(lng));
		data.put(COLUMN_LANDMARK, landmark.getText().toString());
		sql.insertComplaints(data);
		Intent d = new Intent();
		SQLhelper sl = new SQLhelper(this);
		RequestTask req = new RequestTask();
		
		String URL = "http://municipalithree.appspot.com/api/?phno="+sl.getPHONES()+"&name="+sl.getName()+"&title="+brief.getText().toString()+"&desc="+desc.getText().toString()+"&loc="+Double.toString(lat)+"%2C"+Double.toString(lng)+"&landmark="+landmark.getText().toString();
		//Toast.makeText(getApplicationContext(), URL, Toast.LENGTH_LONG).show();
		req.execute(URL);
		String res = req.get();
		//postData();
		Toast.makeText(getApplicationContext(), res, Toast.LENGTH_LONG).show();
		setResult(1,d);
		finish();
	}
	
	public void postData() {
	    // Create a new HttpClient and Post Header
	    HttpClient httpclient = new DefaultHttpClient();
	    HttpPost httppost = new HttpPost("http://www.google.com");

	    try {
	        // Add your data
	        List<NameValuePair> nameValuePairs = new ArrayList<NameValuePair>(2);
	        nameValuePairs.add(new BasicNameValuePair("id", "12345"));
	        nameValuePairs.add(new BasicNameValuePair("stringdata", "Hi"));
	        httppost.setEntity(new UrlEncodedFormEntity(nameValuePairs));

	        // Execute HTTP Post Reques
	        HttpResponse response = httpclient.execute(httppost);
	    } catch (ClientProtocolException e) {
	        // TODO Auto-generated catch block
	    } catch (IOException e) {
	        // TODO Auto-generated catch block
	    }
	    return;
	} 

}