package com.example.municipali3;

import android.location.Location;

public class Complaint {
	public String Complaint;
	public String Description;
	public Location loc;
	public Complaint(String c, String d, Location l) {
		
		Complaint = c;
		Description = d;
		loc = l;
		// TODO Auto-generated constructor stub
	}
	public Complaint()
	{
	
	}
	public void setComplaint(String s)
	{
		Complaint = s;
		return;
	}
	public void setDescription(String s)
	{
		Description = s;
		return;
	}
	public void setLocation(double lat, double lng)
	{
		loc.setLatitude(lat);
		loc.setLongitude(lng);
		return;
	}
	public String getComplaint()
	{
		return Complaint;
	}
	public String getDescription()
	{
		return Description;
	}
	public Location getcLocation()
	{
		return loc;
	}

}
